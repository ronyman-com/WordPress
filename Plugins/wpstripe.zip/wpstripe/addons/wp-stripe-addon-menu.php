<?php

function wp_stripe_display_addon_menu()
{
    echo '<div class="wrap">';
    echo '<h2>' .__('WpStripe addon', 'wp-paypal') . '</h2>';
    echo '<link type="text/css" rel="stylesheet" href="'.WP_STRIPE_URL.'/addons/wp-stripe-addon-menu.css" />' . "\n";
    
    $addon_data = array();

    $addon_1 = array(
        'name' => 'Variable Price',
        'thumbnail' => WP_STRIPE_URL.'/addons/images/wpstripe_addons1.png',
        'description' => 'Let buyers set the amount they will pay or donation 
        With this custom amount as need.',
        'page_url' => 'https://wpstripe.au/plugins/Addons',
    );
    array_push($addon_data, $addon_1);
    
    $addon_2 = array(
        'name' => 'Variable Quantity',
        'thumbnail' => WP_STRIPE_URL.'/addons/images/wpstripe_addons2.png',
        'description' => 'Let buyers set the quantity they will purchase in total at the checkout time.',
        'page_url' => 'https://wpstripe.au/plugins/Addons',
    );
    array_push($addon_data, $addon_2);
    
    //Display the list
    $output = '';
    foreach ($addon_data as $addon) {
        $output .= '<div class="wp_stripe_addon_item_canvas">';

        $output .= '<div class="wp_stripe_addon_item_thumb">';
        $img_src = $addon['thumbnail'];
        $output .= '<img src="' . $img_src . '" alt="' . $addon['name'] . '">';
        $output .= '</div>'; //end thumbnail

        $output .='<div class="wp_stripe_addon_item_body">';
        $output .='<div class="wp_stripe_addon_item_name">';
        $output .= '<a href="' . $addon['page_url'] . '" target="_blank">' . $addon['name'] . '</a>';
        $output .='</div>'; //end name

        $output .='<div class="wp_stripe_addon_item_description">';
        $output .= $addon['description'];
        $output .='</div>'; //end description

        $output .='<div class="wp_stripe_addon_item_details_link">';
        $output .='<a href="'.$addon['page_url'].'" class="wp_stripe_addon_view_details" target="_blank">View Details</a>';
        $output .='</div>'; //end detils link      
        $output .='</div>'; //end body

        $output .= '</div>'; //end canvas
    }
    echo $output;
    
    echo '</div>';//end of wrap
}
