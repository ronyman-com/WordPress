<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * HELPER COMMENT START
 * 
 * This class is used to bring your plugin to life. 
 * All the other registered classed bring features which are
 * controlled and managed by this class.
 * 
 * Within the add_hooks() function, you can register all of 
 * your WordPress related actions and filters as followed:
 * 
 * add_action( 'my_action_hook_to_call', array( $this, 'the_action_hook_callback', 10, 1 ) );
 * or
 * add_filter( 'my_filter_hook_to_call', array( $this, 'the_filter_hook_callback', 10, 1 ) );
 * or
 * add_shortcode( 'my_shortcode_tag', array( $this, 'the_shortcode_callback', 10 ) );
 * 
 * Once added, you can create the callback function, within this class, as followed: 
 * 
 * public function the_action_hook_callback( $some_variable ){}
 * or
 * public function the_filter_hook_callback( $some_variable ){}
 * or
 * public function the_shortcode_callback( $attributes = array(), $content = '' ){}
 * 
 * 
 * HELPER COMMENT END
 */

/**
 * Class Wpstripe_Run
 *
 * Thats where we bring the plugin to life
 *
 * @package		WPSTRIPE
 * @subpackage	Classes/Wpstripe_Run
 * @author		ronyman.com
 * @since		1.0.0
 */
class Wpstripe_Run{

	/**
	 * The options panel settings
	 *
	 * @since	1.0.0
	 * @var		array $options_panel The current options of the options panel
	 */
	private $options_panel;

	/**
	 * Our Wpstripe_Run constructor 
	 * to run the plugin logic.
	 *
	 * @since 1.0.0
	 */
	function __construct(){
		$this->add_hooks();
	}

	/**
	 * ######################
	 * ###
	 * #### WORDPRESS HOOKS
	 * ###
	 * ######################
	 */

	/**
	 * Registers all WordPress and plugin related hooks
	 *
	 * @access	private
	 * @since	1.0.0
	 * @return	void
	 */
	private function add_hooks(){
	
		add_action( 'plugin_action_links_' . WPSTRIPE_PLUGIN_BASE, array( $this, 'add_plugin_action_link' ), 20 );
		add_shortcode( 'wpstripe', array( $this, 'add_shortcode_callback' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_backend_scripts_and_styles' ), 20 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_scripts_and_styles' ), 20 );
		add_action( 'wp_ajax_my_demo_ajax_call', array( $this, 'my_demo_ajax_call_callback' ), 20 );
		add_action( 'heartbeat_received', array( $this, 'myplugin_receive_heartbeat' ), 20, 2 );
		add_action( 'admin_menu', array( $this, 'register_custom_admin_menu_pages' ), 20 );
		add_action( 'admin_init', array( $this, 'register_custom_admin_options_panel' ), 20 );
		add_action( 'admin_bar_menu', array( $this, 'add_admin_bar_menu_items' ), 100, 1 );
		add_action( 'rest_api_init', array( $this, 'add_rest_api_endpoints' ), 20 );
		add_action( 'wp_dashboard_setup', array( $this, 'manage_dashboard_widgets' ), 20 );
		add_action( 'init', array( $this, 'add_custom_post_type' ), 20 );
		add_filter( 'edd_settings_sections_extensions', array( $this, 'add_edd_settings_section' ), 20 );
		add_filter( 'edd_settings_extensions', array( $this, 'add_edd_settings_section_content' ), 20 );
		add_filter( 'woocommerce_get_sections_products', array( $this, 'wc_add_custom_settings_page' ), 20 );
		add_filter( 'woocommerce_get_settings_products', array( $this, 'wc_custom_settings_tab_content' ), 20, 2 );
		add_action( 'acf/init', array( $this, 'add_custom_acf_options_page' ), 20 );
		register_activation_hook( WPSTRIPE_PLUGIN_FILE, array( $this, 'activation_hook_callback' ) );
		register_deactivation_hook( WPSTRIPE_PLUGIN_FILE, array( $this, 'deactivation_hook_callback' ) );
	
	}

	/**
	 * ######################
	 * ###
	 * #### WORDPRESS HOOK CALLBACKS
	 * ###
	 * ######################
	 */

	/**
	* Adds action links to the plugin list table
	*
	* @access	public
	* @since	1.0.0
	*
	* @param	array	$links An array of plugin action links.
	*
	* @return	array	An array of plugin action links.
	*/
	public function add_plugin_action_link( $links ) {

		$links['our_shop'] = sprintf( '<a href="%s" title="Go to Pro Version" style="font-weight:700;">%s</a>', 'https://wpstripe.au', __( 'Go to Pro Version', 'wpstripe' ) );

		return $links;
	}

	/**
	 * Add the shortcode callback for [wpstripe]
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$attr		Additional attributes you have added within the shortcode tag.
	 * @param	string	$content	The content you added between an opening and closing shortcode tag.
	 *
	 * @return	string	The customized content by the shortcode.
	 */
	public function add_shortcode_callback( $attr = array(), $content = '' ) {

		$content .= ' this content is added by the add_shortcode_callback() function';

		return $content;
	}

	/**
	 * Enqueue the backend related scripts and styles for this plugin.
	 * All of the added scripts andstyles will be available on every page within the backend.
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function enqueue_backend_scripts_and_styles() {
		wp_enqueue_style( 'wpstripe-backend-styles', WPSTRIPE_PLUGIN_URL . 'core/includes/assets/css/backend-styles.css', array(), WPSTRIPE_VERSION, 'all' );

		if( ! wp_script_is( 'heartbeat' ) ){
			//enqueue the Heartbeat API
			wp_enqueue_script( 'heartbeat' );
		}

		wp_enqueue_script( 'wpstripe-backend-scripts', WPSTRIPE_PLUGIN_URL . 'core/includes/assets/js/backend-scripts.js', array( 'jquery' ), WPSTRIPE_VERSION, true );
		wp_localize_script( 'wpstripe-backend-scripts', 'wpstripe', array(
			'plugin_name'   	=> __( WPSTRIPE_NAME, 'wpstripe' ),
			'ajaxurl' 			=> admin_url( 'admin-ajax.php' ),
			'security_nonce'	=> wp_create_nonce( "your-nonce-name" ),
		));
	}


	/**
	 * Enqueue the frontend related scripts and styles for this plugin.
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function enqueue_frontend_scripts_and_styles() {
		wp_enqueue_style( 'wpstripe-frontend-styles', WPSTRIPE_PLUGIN_URL . 'core/includes/assets/css/frontend-styles.css', array(), WPSTRIPE_VERSION, 'all' );
	}


	/**
	 * The callback function for my_demo_ajax_call
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function my_demo_ajax_call_callback() {
		check_ajax_referer( 'your-nonce-name', 'ajax_nonce_parameter' );

		$demo_data = isset( $_REQUEST['demo_data'] ) ? sanitize_text_field( $_REQUEST['demo_data'] ) : '';
		$response = array( 'success' => false );

		if ( ! empty( $demo_data ) ) {
			$response['success'] = true;
			$response['msg'] = __( 'The value was successfully filled.', 'wpstripe' );
		} else {
			$response['msg'] = __( 'The sent value was empty.', 'wpstripe' );
		}

		if( $response['success'] ){
			wp_send_json_success( $response );
		} else {
			wp_send_json_error( $response );
		}

		die();
	}


	/**
	 * The callback function for heartbeat_received
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$response	Heartbeat response data to pass back to front end.
	 * @param	array	$data		Data received from the front end (unslashed).
	 *
	 * @return	array	$response	The adjusted heartbeat response data
	 */
	public function myplugin_receive_heartbeat( $response, $data ) {

		//If we didn't receive our data, don't send any back.
		if( empty( $data['myplugin_customfield'] ) ){
			return $response;
		}

		// Calculate our data and pass it back. For this example, we'll hash it.
		$received_data = $data['myplugin_customfield'];

		$response['myplugin_customfield_hashed'] = sha1( $received_data );

		return $response;
	}

	/**
	 * Add custom menu pages
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function register_custom_admin_menu_pages(){

		add_submenu_page( 'wpstripe payment', 'WpStripe Payment', 'WpStripe', WPSTRIPE()->settings->get_capability( 'custom-menu-page' ), 'wp-stripe', array( $this, 'custom_admin_menu_page_callback' ), 5 );

	}

	/**
	 * Add custom menu page content for the following
	 * menu item: wp-stripe
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function custom_admin_menu_page_callback(){

		$this->options_panel = get_option( 'my_custom_options' );

		?>
		<div class="wrap">
			<h1>Custom Options Panel</h1>
			<form method="post" action="options.php">
				<?php
					settings_fields( 'my_custom_options_group' );
					do_settings_sections( 'custom-options-panel' );
					submit_button();
				?>
			</form>
		</div>
		<?php

	}

	/**
	 * Register and add the settings
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function register_custom_admin_options_panel(){

		//Register the settings
		register_setting(
			'my_custom_options_group', //The option group
			'my_custom_options', //The option name
			array( $this, 'sanitize_options_panel' )
		);

		//Add the settings section
		add_settings_section(
			'setting_section_id',
			__( 'Custom Options Panel', 'wpstripe' ),
			array( $this, 'print_options_section' ),
			'custom-options-panel'
		);

		//Add all settings fields
		add_settings_field(
			'title_example', 
			__( 'Title', 'wpstripe' ), 
			array( $this, 'title_example_callback' ), 
			'custom-options-panel', 
			'setting_section_id'
		);

		add_settings_field(
			'number_example',
			__( 'ID Number', 'wpstripe' ), 
			array( $this, 'number_example_callback' ),
			'custom-options-panel',
			'setting_section_id'
		);

	}

	/**
	 * Sanitize the registered settings
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$input Contains all settings fields
	 *
	 * @return	array	The sanitized $input fields
	 */
	public function sanitize_options_panel( $input ){

		if( isset( $input['title_example'] ) ){
			$input['title_example'] = sanitize_text_field( $input['title_example'] );
		}

		if( isset( $input['number_example'] ) ){
			$input['number_example'] = absint( $input['number_example'] );
		}

		return $input;
	}

	/**
	 * Print the section text for the registered options section
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function print_options_section(){
		print 'This is a custom option panel. Please add your settings down below.';
	}

	/**
	 * Print the content for the title_example setting
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function title_example_callback(){
		printf(
			'<input type="text" id="title_example" name="my_custom_options[title_example]" value="%s" />',
			isset( $this->options_panel['title_example'] ) ? esc_attr( $this->options_panel['title_example']) : ''
		);
	}

	/**
	 * Print the content for the number_example setting
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function number_example_callback(){
		printf(
			'<input type="number" id="number_example" name="my_custom_options[number_example]" value="%s" />',
			isset( $this->options_panel['number_example'] ) ? esc_attr( $this->options_panel['number_example']) : ''
		);
	}

	/**
	 * Add a new menu item to the WordPress topbar
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	object $admin_bar The WP_Admin_Bar object
	 *
	 * @return	void
	 */
	public function add_admin_bar_menu_items( $admin_bar ) {

		$admin_bar->add_menu( array(
			'id'		=> 'wpstripe-id', // The ID of the node.
			'title'		=> __( 'WpStripe', 'wpstripe','Create Payment' ), // The text that will be visible in the Toolbar. Including html tags is allowed.
			'parent'	=> false, // The ID of the parent node.
			'href'		=> '#', // The ‘href’ attribute for the link. If ‘href’ is not set the node will be a text node.
			'group'		=> false, // This will make the node a group (node) if set to ‘true’. Group nodes are not visible in the Toolbar, but nodes added to it are.
			'meta'		=> array(
				'title'		=> __( 'WpStripe', 'stripe Payment getway', ), // The title attribute. Will be set to the link or to a div containing a text node.
				'target'	=> '_blank', // The target attribute for the link. This will only be set if the ‘href’ argument is present.
				'class'		=> 'wpstripe-class', // The class attribute for the list item containing the link or text node.
				'html'		=> false, // The html used for the node.
				'rel'		=> false, // The rel attribute.
				'onclick'	=> false, // The onclick attribute for the link. This will only be set if the ‘href’ argument is present.
				'tabindex'	=> false, // The tabindex attribute. Will be set to the link or to a div containing a text node.
			),
		));

		$admin_bar->add_menu( array(
			'id'		=> 'wpstripe-sub-id',
			'title'		=> __( 'WpStripe', 'Create Payment' ),
			'parent'	=> 'wpstripe-id',
			'href'		=> '#',
			'group'		=> false,
			'meta'		=> array(
				'title'		=> __( 'WpStripe', 'Create Payment' ),
				'target'	=> '_blank',
				'class'		=> 'wpstripe-sub-class',
				'html'		=> false,    
				'rel'		=> false,
				'onclick'	=> false,
				'tabindex'	=> false,
			),
		));

	}

	/**
	 * Add the REST API endpoints for this plugin
	 *
	 * Accessibility:
	 * https://domain.com/wp-json/wpstripe/v1/demo/4
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function add_rest_api_endpoints() {

		if( ! class_exists( 'WP_REST_Server' ) ){
			return;
		}

		register_rest_route( 'wpstripe/v1', '/demo/(?P<id>\d+)', array(
			array(
				'methods'  => \WP_REST_Server::READABLE,
				'callback' => array( $this, 'prepare_rest_api_demo_response' ),
				'permission_callback' => function( $request ) {
					return true; //Change to limit access
				},
				'args' => array(
					'id' => array(
						'validate_callback' => function($param, $request, $key) {
							return is_numeric( $param );
						}
					),
				),
			),
		) );

	}

	/**
	 * The callback for the demo REST API endpoint
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	object|WP_REST_Request $request Full data about the request.
	 *
	 * @return	object|WP_REST_Response
	 */
	public function prepare_rest_api_demo_response( $request ){
		$response = array(
			'success' => false,
			'msg' => '',
		);

		$id = $request->get_param( 'id' );

		if( is_numeric( $id ) ){
			$response['success'] = true;
			$response['msg'] = __( 'The response was successful. The number you added:', 'wpstripe' ) . ' ' . intval( $id );
			return new WP_REST_Response( $response, 200 );
		}

		$response['msg'] = __( 'The given id is not a number.', 'wpstripe' );
		return new WP_REST_Response( $response, 500 );
	}

	/**
	 * Adds all plugin related dashbaord widgets
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function manage_dashboard_widgets() {

		wp_add_dashboard_widget( 'demo_widget', __( 'WpStripe Order', 'wpstripe' ), array( $this, 'order_widget_callback' ), null, array() );

	}

	/**
	 * The callback for the "WpStripe Demo" widget
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	object	$object	Often this is the object that's the focus of the current screen, for example a WP_Post or WP_Comment object.
	 * @param	array	$args	Data that should be set as the $args property of the widget array (which is the fifth parameter passed to the wp_add_dashboard_widget function call)
	 *
	 * @return	void
	 */
	public function order_widget_callback( $object, $args ){
		?>
<p>WpStripe Order</p>
		<?php
	}

	/**
	 * Add all of the available custom post types
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function add_custom_post_type(){

		$labels = array(
			'name'                  => _x( 'WpStripe Products', 'Post type general name', 'wpstripe' ),
			'singular_name'         => _x( 'Products', 'Post type singular name', 'wpstripe' ),
			'menu_name'             => _x( '', 'Admin Menu text', 'wpstripe' ),
			'name_admin_bar'        => _x( 'Add New on Toolbar', 'wpstripe' ),
			'add_new'               => __( 'Add New', 'wpstripe' ),
			'add_new_item'          => __( 'Add New Product', 'wpstripe' ),
			'new_item'              => __( 'New Product', 'wpstripe' ),
			'edit_item'             => __( 'Edit Product', 'wpstripe' ),
			'view_item'             => __( 'View Product', 'wpstripe' ),
			'all_items'             => __( 'All ', 'wpstripe' ),
			'search_items'          => __( 'Search ', 'wpstripe' ),
			'parent_item_colon'     => __( 'Parent :', 'wpstripe' ),
			'not_found'             => __( 'No  found.', 'wpstripe' ),
			'not_found_in_trash'    => __( 'No  found in Trash.', 'wpstripe' ),
			'featured_image'        => _x( 'Product Cover Image', 'Overrides the "Featured Image" phrase for this post type.', 'wpstripe' ),
			'set_featured_image'    => _x( 'Set cover image', 'Overrides the "Set featured image" phrase for this post type.', 'wpstripe' ),
			'remove_featured_image' => _x( 'Remove cover image', 'Overrides the "Remove featured image" phrase for this post type.', 'wpstripe' ),
			'use_featured_image'    => _x( 'Use as cover image', 'Overrides the "Use as featured image" phrase for this post type.', 'wpstripe' ),
			'archives'              => _x( 'Product archives', 'The post type archive label used in nav menus. Default "Post Archives".', 'wpstripe' ),
			'insert_into_item'      => _x( 'Insert into Product', 'Overrides the "Insert into post"/"Insert into page" phrase (used when inserting media into a post).', 'wpstripe' ),
			'uploaded_to_this_item' => _x( 'Uploaded to this Product', 'Overrides the "Uploaded to this post"/"Uploaded to this page" phrase (used when viewing media attached to a post).', 'wpstripe' ),
			'filter_items_list'     => _x( 'Filter  list', 'Screen reader text for the filter links heading on the post type listing screen. Default "Filter posts list"/"Filter pages list".', 'wpstripe' ),
			'items_list_navigation' => _x( ' list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default "Posts list navigation"/"Pages list navigation".', 'wpstripe' ),
			'items_list'            => _x( ' list', 'Screen reader text for the items list heading on the post type listing screen. Default "Posts list"/"Pages list".', 'wpstripe' ),
		);

		$supports = array(
			'title',			// post title
			'editor',			// post content
			'author',			// post author
			'thumbnail',		// featured image
			'excerpt',			// post excerpt
			'custom-fields',	// custom fields
			'comments',			// post comments
			'revisions',		// post revisions
			'post-formats',		// post formats
		);

		$args = array(
			'labels'				=> $labels,
			'supports' 				=> $supports,
			'public'				=> true,
			'publicly_queryable'	=> true,
			'show_ui'				=> true,
			'show_in_menu'			=> true,
			'query_var'				=> true,
			'rewrite'				=> array( 'slug' => 'order' ),
			'capability_type'		=> 'post',
			'has_archive'			=> true,
			'hierarchical'			=> false,
			'menu_position'			=> null,
		);

		register_post_type( 'wpstripe_product', $args );
		
	}

	/**
	 * Add the custom settings section under
	 * Downloads -> Settings -> Extensions
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$sections	The currently registered EDD settings sections
	 *
	 * @return	void
	 */
	public function add_edd_settings_section( $sections ) {
		
		$sections['wpstripe'] = __( WPSTRIPE()->settings->get_plugin_name(), 'wpstripe' );

		return $sections;
	}

	/**
	 * Add the custom settings section content
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$settings	The currently registered EDD settings for all registered extensions
	 *
	 * @return	array	The extended settings 
	 */
	public function add_edd_settings_section_content( $settings ) {
		
		// Your settings reamain registered as they were in EDD Pre-2.5
		$custom_settings = array(
			array(
				'id'   => 'my_header',
				'name' => '<strong>' . __( WPSTRIPE()->settings->get_plugin_name() . 'Settings', 'wpstripe' ) . '</strong>',
				'desc' => '',
				'type' => 'header',
				'size' => 'regular'
			),
			array(
				'id'    => 'my_example_setting',
				'name'  => __( 'Example checkbox', 'wpstripe' ),
				'desc'  => __( 'Check this to turn on a setting', 'wpstripe' ),
				'type'  => 'checkbox'
			),
			array(
				'id'    => 'my_example_text',
				'name'  => __( 'Example text', 'wpstripe' ),
				'desc'  => __( 'A Text setting', 'wpstripe' ),
				'type'  => 'text',
				'std'   => __( 'Example default text', 'wpstripe' )
			),
		);

		// If EDD is at version 2.5 or later...
		if ( version_compare( EDD_VERSION, 2.5, '>=' ) ) {
			$custom_settings = array( 'wpstripe' => $custom_settings );
		}

		return array_merge( $settings, $custom_settings );
	}

	/**
	 * Add the custom page settings under
	 * Woocommerce -> Settings -> Products
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$settings_tab	The currently registered Woocommerce settings tabs
	 *
	 * @return	void
	 */
	public function wc_add_custom_settings_page( $settings_tab ) {
		
		$settings_tab['wc_custom_settings_tab'] = __( 'WpStripe', 'wpstripe' );

		return $settings_tab;
	}

	/**
	 * Add the custom settings page content
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @param	array	$settings	The currently registered Woocommerce settings for all registered tabs
	 *
	 * @return	array	The extended settings 
	 */
	public function wc_custom_settings_tab_content( $settings, $current_section ) {
		
		if( 'wc_custom_settings_tab' == $current_section ) {

			$custom_settings = array();

			$custom_settings[] = array(
				'title' => __( 'First Section', 'wpstripe' ),
				'desc'  => __( 'The title above is a section title implying the first section of this settings page. In case you want to learn more about custom setings, please check out the following link:', 'wpstripe' ) . '<br><a href="https://docs.woocommerce.com/document/adding-a-section-to-a-settings-tab/" target="_blank">https://docs.woocommerce.com/document/adding-a-section-to-a-settings-tab/</a>',
				'type'  => 'title',
				'id'    => 'custom_section_1',
			);

			$custom_settings[] = array(
				'title'         => __( 'First Title', 'wpstripe' ),
				'desc'          => __( 'The first settings description', 'wpstripe' ),
				/* Translators: %s URL to tracking info screen. */
				'desc_tip'      => __( 'This is the description tip. You can include further details here that help the user to know what this setting does.', 'wpstripe' ),
				'id'            => 'custom_first_setting',
				'type'          => 'checkbox',
				'checkboxgroup' => 'start',
				'default'       => 'no',
				'autoload'      => false,
			);

			$custom_settings[] = array(
				'type' => 'sectionend',
				'id'   => 'custom_section_1',
			);

			$custom_settings[] = array(
				'title' => __( 'Second Section', 'wpstripe' ),
				'desc'  => __( 'The title above is a section title implying the second section of this settings page.', 'wpstripe' ),
				'type'  => 'title',
				'id'    => 'custom_section_2',
			);

			$custom_settings[] = array(
				'name'     => __( 'Settings Title', 'wpstripe' ),
				'desc_tip' => __( 'This is the description tip for a input field. Place further tips of the setting here.', 'wpstripe' ),
				'id'       => 'wcslider_title',
				'type'     => 'text',
				'desc'     => __( 'Include further details about your setting here.', 'wpstripe' ),
			);

			$custom_settings[] = array(
				'type' => 'sectionend',
				'id'   => 'custom_section_2',
			);

			$settings = $custom_settings;
		}

		return $settings;
	}

	/**
	 * Add the Advanced Custom fields
	 * options pages
	 *
	 * @access	public
	 * @since	1.0.0
	 * @link	https://www.advancedcustomfields.com/resources/acf_add_options_page/
	 *
	 * @return	void
	 */
	public function add_custom_acf_options_page() {

		// Check function exists.
		if( function_exists('acf_add_options_page') ) {

			// Register options page.
			$option_page = acf_add_options_page( array(
				'page_title'    => __('WpStripe Addon'),
				'menu_title'    => __('WpStripe Payment'),
				'menu_slug'     => 'wpstripe-addon',
				'capability'    => 'edit_posts',
				'redirect'      => false
			) );

			$child = acf_add_options_page(array(
				'page_title'  => __('Sub WpStripe Addon'),
				'menu_title'  => __('Sub WpStripe Payment'),
				'parent_slug' => 'wpstripe-addon',
			));

		}

	}

	/**
	 * ####################
	 * ### Activation/Deactivation hooks
	 * ####################
	 */
	 
	/*
	 * This function is called on activation of the plugin
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function activation_hook_callback(){

		//Your code
		
	}

	/*
	 * This function is called on deactivation of the plugin
	 *
	 * @access	public
	 * @since	1.0.0
	 *
	 * @return	void
	 */
	public function deactivation_hook_callback(){

		//Your code
		
	}

}
