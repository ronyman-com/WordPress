<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * HELPER COMMENT START
 * 
 * This class contains all of the available CLI commands for your plugin. 
 * Down below, we added a command that allows you to display the current 
 * details about your plugin within the console. 
 * 
 * To test the command, please head over to your WordPress instance and type in the following
 * 
 * wp wpstripe details
 * 
 * HELPER COMMENT END
 */

WP_CLI::add_command( 'wpstripe', 'Wpstripe_CLI' );

/**
 * Class Wpstripe_CLI
 *
 * This class contains all WP CLI related features.
 *
 * @package		WPSTRIPE
 * @subpackage	Classes/Wpstripe_CLI
 * @author		ronyman.com
 * @since		1.0.0
 */
class Wpstripe_CLI extends WP_CLI_Command {

	/**
	 * Our Wpstripe_CLI constructor 
	 * to run the plugin CLI logic.
	 *
	 * @since 1.0.0
	 */
	function __construct(){
	}


	/**
	 * Get plugin details
	 *
	 * ## OPTIONS
	 *
	 * None. Returns basic info regarding the plugin instance.
	 *
	 * ## EXAMPLES
	 *
	 * To access this feature, type the following into your console:
	 * wp wpstripe details
	 *
	 * @param		array $args
	 * @param		array $assoc_args
	 * @return		void
	 */
	public function details( $args, $assoc_args ) {
		WP_CLI::line( sprintf( __( 'Plugin name: %s', 'WpStripe' ), WPSTRIPE_NAME ) );
		WP_CLI::line( sprintf( __( 'Plugin version: %s', 'WpStripe' ), WPSTRIPE_VERSION ) );
    }
    
}
