=== WpStripe ===
Author URI: https://www.ronyman.com/
Plugin URI: https://wpstripe.au
Donate link: 
Contributors: ronyman.com
Tags: wpstripe
Requires at least: 
Tested up to: 
Requires PHP: 7.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Stripe Payment Gateway for Woo Commerce Store .

== Description ==

WordPress Payment gateway with Stripe Paynow button

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.


== Installation ==

1. Go to `Plugins` in the Admin menu
2. Click on the button `Add new`
3. Search for `WpStripe` and click 'Install Now' or click on the `upload` link to upload `wpstripe.zip`
4. Click on `Activate plugin`

== Changelog ==

= 1.0.0: April 11, 2022 =
* Birthday of WpStripe